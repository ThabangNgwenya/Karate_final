# Distributed Testing

Please refer to the wiki: [Distributed Testing](https://github.com/karatelabs/karate/wiki/Distributed-Testing).

# Docker

How to run Web-UI tests using Docker without even Java or Maven installed.

Please refer to the wiki: [Docker](https://github.com/karatelabs/karate/wiki/Docker).

# Gradle

This project also has a sample [`build.gradle`](build.gradle). Also see the wiki: [Gradle](https://github.com/karatelabs/karate/wiki/Gradle).