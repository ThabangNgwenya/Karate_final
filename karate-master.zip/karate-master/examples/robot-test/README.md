# Examples - Karate Robot

This is designed to be a simple Maven project to get started with [`karate-robot`](https://github.com/karatelabs/karate/tree/master/karate-robot).

* [`chrome.feature`](src/test/java/chrome/chrome.feature) - this example will switch to Google Chrome (assumed to be open) and perform a search using only keystrokes and navigation using image-detection