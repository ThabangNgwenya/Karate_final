// test comment
function fn() {
  return {
    configSource: 'custom-env'
  };
}
