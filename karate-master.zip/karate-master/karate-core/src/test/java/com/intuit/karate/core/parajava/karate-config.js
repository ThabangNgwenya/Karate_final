function karateConfig() {
  return karate.callSingle('setup.feature');
}