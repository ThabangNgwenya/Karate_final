function fn() {
  return { 'cookie-id': java.lang.System.currentTimeMillis() + '' };
}
