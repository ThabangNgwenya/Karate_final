function fn() {
  return {};
}
