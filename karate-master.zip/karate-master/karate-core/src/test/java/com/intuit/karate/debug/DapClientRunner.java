package com.intuit.karate.debug;

import org.junit.jupiter.api.Test;

class DapClientRunner {
    
    @Test
    void testClient() {
        new DapClient();
    }
    
}
